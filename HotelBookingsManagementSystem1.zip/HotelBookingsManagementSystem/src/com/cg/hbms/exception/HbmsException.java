package com.cg.hbms.exception;

public class HbmsException extends Exception{

	public HbmsException(String message)
	{
		super(message);
	}

}
