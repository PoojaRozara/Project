package com.cg.hbms.service;

import com.cg.hbms.dao.CustomerDao;
import com.cg.hbms.dao.CustomerDaoImpl;
import com.cg.hbms.dto.UserDto;

public class CustomerServiceImpl implements CustomerService {

	CustomerDao customerDao=new CustomerDaoImpl();
	@Override
	public boolean addNewCustomer(UserDto user) {
		
		return customerDao.addNewCustomer(user);
	}
	@Override
	public boolean authenticate(String userId, String password) {
		
		return customerDao.authenticate(userId, password);
	}

}
