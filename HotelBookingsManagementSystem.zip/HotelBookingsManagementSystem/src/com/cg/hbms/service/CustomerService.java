package com.cg.hbms.service;

import com.cg.hbms.dto.UserDto;

public interface CustomerService {
	
	public boolean addNewCustomer(UserDto user);
	public boolean authenticate(String strUserId,String password);

}
