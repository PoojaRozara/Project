package com.cg.hbms.dao;

import com.cg.hbms.dto.UserDto;

public interface CustomerDao {
	public boolean addNewCustomer(UserDto user);
	public boolean authenticate(String strUserId,String password);

}
