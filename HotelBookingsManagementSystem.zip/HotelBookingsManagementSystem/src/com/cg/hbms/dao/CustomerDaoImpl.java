package com.cg.hbms.dao;

import java.util.Map.Entry;

import com.cg.hbms.dto.UserDto;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public boolean addNewCustomer(UserDto user) {
		StaticDb data=new StaticDb();
		data.getUserData().put(user.getUserId(), user);
		return true;
	}

	@Override
	public boolean authenticate(String userId, String password) {
		Integer customerUserId = Integer.parseInt(userId);
		for (Entry<Integer, UserDto> user : StaticDb.getUserData().entrySet())  
            if(user.getKey().equals(customerUserId) && user.getValue().getPassword().equals(password)&& user.getValue().getRole().equals("user"))
            {
            	return true;
            }
		return false;
	}

}
