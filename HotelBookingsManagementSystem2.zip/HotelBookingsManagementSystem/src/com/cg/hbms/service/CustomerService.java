package com.cg.hbms.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDto;
import com.cg.hbms.dto.UserDto;
import com.cg.hbms.exception.NoRoomsAvailableException;

public interface CustomerService {
	
	public boolean addNewCustomer(UserDto user);
	public boolean authenticate(Integer userId,String password);
	public ArrayList<BookingDto> viewBookingTransaction(Integer userId);
	public ArrayList<HotelDto> displayHotels(String city);
	public Boolean validatefromDate(LocalDate fromDate);
	public HashMap<Integer, RoomDto> displayRoomsBasedOnType(int hotelId, LocalDate fromDate, LocalDate toDate, int type)
			throws NoRoomsAvailableException;
	public Boolean validateDate(LocalDate fromDate,LocalDate toDate);
	public int validateNoOfDays(LocalDate fromDate,LocalDate toDate);
	public double getPrice(int roomId);
	
	public boolean bookRoom(int roomId,int hotelId, int userId, LocalDate bookedFrom, LocalDate bookedTo, int noOfAdults,int noOfChildren,double amount);
	
}
