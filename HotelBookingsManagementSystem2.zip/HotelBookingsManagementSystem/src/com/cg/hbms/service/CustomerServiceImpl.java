package com.cg.hbms.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.hbms.dao.CustomerDao;
import com.cg.hbms.dao.CustomerDaoImpl;
import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDto;
import com.cg.hbms.dto.UserDto;
import com.cg.hbms.exception.NoRoomsAvailableException;

public class CustomerServiceImpl implements CustomerService {

	CustomerDao customerDao=new CustomerDaoImpl();
	@Override
	public boolean addNewCustomer(UserDto user) {
		
		return customerDao.addNewCustomer(user);
	}
	@Override
	public boolean authenticate(Integer userId, String password) {
		
		return customerDao.authenticate(userId, password);
	}
	@Override
	public ArrayList<BookingDto> viewBookingTransaction(Integer userId) {
		
		return customerDao.viewBookingTransaction(userId);
	}
	@Override
	public ArrayList<HotelDto> displayHotels(String city) {
		
		return customerDao.displayHotels(city);
	}
	@Override
	public Boolean validatefromDate(LocalDate fromDate) {
		if(fromDate.isEqual(LocalDate.now()) || fromDate.isAfter(LocalDate.now()))
		{
			return true;
		}
		else
			return false;
	}
	
	@Override
	 public HashMap<Integer,RoomDto> displayRoomsBasedOnType(int hotelId,LocalDate fromDate,LocalDate toDate,int type) throws NoRoomsAvailableException
	 {
		 String roomType;
			if(type==1)
			{
				roomType="Ac";
			}
			else
			{
				roomType="NonAc";

			}
		
		ArrayList<BookingDto> bookList=customerDao.fetchBookingdetails( hotelId);
		List<RoomDto> roomList =customerDao.fetchRoomsByHotelId(hotelId);
	    HashMap <Integer,RoomDto> roomHashMap=new HashMap<Integer,RoomDto>();
		
		if(bookList==null)
		{
			
		}
		else
		{
	   
		for(RoomDto room:roomList)
		{
			if(room.getRoomType().equals(roomType))
			{
			for(BookingDto book: bookList)
			{
			if(room.getRoomId()==book.getRoomId())
			{
				if(fromDate.isBefore(book.getBookedFrom())   &&( toDate.isBefore(book.getBookedFrom())   || toDate.isEqual(book.getBookedFrom()) ))
				{
					room.setAvailability(true); 
				}
				
				else	if(fromDate.isAfter(book.getBookedTo()) || fromDate.isEqual(book.getBookedTo())    )
				{room.setAvailability(true); 
					
				}
				else
				{
					room.setAvailability(false);
					break;
				}
			}
			}
			}
			
		}
		}
		
		
		for(RoomDto room:roomList){
			if(room.getRoomType().equals(roomType)  &&  room.isAvailability()==true)
			{
			roomHashMap.put(room.getRoomId(),room);
			}
				}
		if(roomHashMap.isEmpty())
		{
			throw new NoRoomsAvailableException();
		}
		return roomHashMap;
	 }
	@Override
	public Boolean validateDate(LocalDate fromDate, LocalDate toDate) {
		if(toDate.isAfter(fromDate) )
		{
			return true;
		}
		else
		{
	       return false;
		}
	}
	@Override
	public int validateNoOfDays(LocalDate fromDate, LocalDate toDate) {
		 int numDays = Period.between(fromDate, toDate).getDays();
		 if(numDays>7)
			 return 0;
		 else
			 return numDays;
	}
	@Override
	public boolean bookRoom(int roomId, int hotelId, int userId, LocalDate bookedFrom, LocalDate bookedTo,int noOfAdults,
			int noOfChildren, double amount) {
		
		
		
		return customerDao.bookRoom(roomId, hotelId, userId, bookedFrom, bookedTo,noOfAdults, noOfChildren, amount);
	}
	@Override
	public double getPrice(int roomId) {
		
		return customerDao.getPrice(roomId);
	}



}
