package com.cg.hbms.dao;

import java.awt.List;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDto;
import com.cg.hbms.dto.UserDto;

public class CustomerDaoImpl implements CustomerDao {
	StaticDb data=new StaticDb();
	static int bookingId=1001;
	
	
	@Override
	public boolean addNewCustomer(UserDto user) {
		
		data.getUserData().put(user.getUserId(), user);
		return true;
	}

	@Override
	public boolean authenticate(Integer userId, String password) {
		Integer customerUserId = (userId);
		for (Entry<Integer, UserDto> user : StaticDb.getUserData().entrySet())  
            if(user.getKey().equals(customerUserId) && user.getValue().getPassword().equals(password)&& user.getValue().getRole().equals("user"))
            {
            	return true;
            }
		return false;
	}

	@Override
	public ArrayList<BookingDto> viewBookingTransaction(Integer userId) {
		ArrayList<BookingDto> result=new ArrayList<BookingDto>();
		for (BookingDto user : StaticDb.getBookingData().values())  
		{
			if(user.getUserId().equals(userId))
			{
				result.add(user);
			}
		}
		return result;
	}

	@Override
	public ArrayList<HotelDto> displayHotels(String city) {
		
		ArrayList<HotelDto> result=new ArrayList<HotelDto>();
		for (HotelDto hotel : StaticDb.getHotelData().values())  
		{
			if(hotel.getHotelCity().equals(city))
			{
				result.add(hotel);
			}
		}
		return result;
	}

	@Override
	public ArrayList<BookingDto> fetchBookingdetails(int hotelId) {
		BookingDto key;
		 Set<Entry<Integer,BookingDto>> bookingEntrySet=StaticDb.getBookingData().entrySet();
		 ArrayList<BookingDto> bookingList=new ArrayList<BookingDto>();
		
		 for(Entry  search:bookingEntrySet )
		 {
			 key=(BookingDto)search.getValue();
			 if(key.getHotelId()==hotelId)
			 {
				 bookingList.add(key);
			 }
		 }
		 
		 return bookingList;
		
	}

	@Override
	public java.util.List<RoomDto> fetchRoomsByHotelId(int hotelId) {
		RoomDto key;
		 ArrayList<RoomDto> tempRoomList=new ArrayList<RoomDto>();
		 Set<Entry<Integer,RoomDto>> roomEntrySet=StaticDb.getRoomData().entrySet();
		 for(Entry  search:roomEntrySet )
		 {
			 key=(RoomDto)search.getValue();
			 if(key.getHotelId()==hotelId)
			 {
				 tempRoomList.add(key);
			 }
		 }
		 
		 return tempRoomList;
	}

	@Override
	public boolean bookRoom(int roomId, int hotelId, int userId, LocalDate bookedFrom, LocalDate bookedTo,int noOfAdults,
			int noOfChildren, double amount) {
		
		data.getBookingData().put((BookingDto.index)+1, new BookingDto(roomId, hotelId, userId, bookedFrom, bookedTo,noOfAdults,noOfChildren, amount));
		return true;
	}
	
	
	@Override
	public double getPrice(int roomId) {
		
		return data.getRoomData().get(roomId).getPerNightRate();
	}

	
}
