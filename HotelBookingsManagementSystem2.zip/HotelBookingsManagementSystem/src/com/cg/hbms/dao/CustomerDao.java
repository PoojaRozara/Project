package com.cg.hbms.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDto;
import com.cg.hbms.dto.UserDto;

public interface CustomerDao {
	public boolean addNewCustomer(UserDto user);
	public boolean authenticate(Integer strUserId,String password);
	public ArrayList<BookingDto> viewBookingTransaction(Integer userId);
	public ArrayList<HotelDto> displayHotels(String city);
	public ArrayList<BookingDto> fetchBookingdetails(int hotelId);
	public List<RoomDto> fetchRoomsByHotelId(int hotelId);
	
	boolean bookRoom(int roomId, int hotelId, int userId, LocalDate bookedFrom, LocalDate bookedTo, int noOfAdults,
			int noOfChildren, double amount);
	double getPrice(int roomId);
	

}
